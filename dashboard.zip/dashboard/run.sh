
git pull
rm -frv /docker/nginx/html/dashboard
cp -r ../dashboard /docker/nginx/html
